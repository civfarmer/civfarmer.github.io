#!/usr/bin/env python3
"""Emplaced-day energy budget (17.3-17.4). Values come from parameters.py.

Reproduces every figure in Part VI from the stated inputs. No figure in the
paper is entered by hand; each is printed by this script.
"""
import math
from dataclasses import dataclass, asdict, field, replace as _replace
from parameters import PARAMS, RANGES as _R, SEED, N_DRAWS

@dataclass
class Params:
    # --- tier one: always live -------------------------------------------
    P1_pwr: float = 500e-6      # W, continuous (geophone + acoustic + MCU deep sleep)
    # --- event model ------------------------------------------------------
    T:      float = 2.0         # genuine events entering the sector, per day
    F1:     float = 200.0       # tier-one false trips per day (wind, rain, fauna, traffic)
    p1:     float = 0.95        # P(tier one registers a genuine event)
    p2:     float = 0.95        # P(tier two confirms a genuine event)
    q2:     float = 0.041       # P(tier two passes a tier-one false trip)
    # --- tier two: woken by tier one --------------------------------------
    P2_pwr: float = 50e-3       # W when live (magnetometer + passive IR)
    t2:     float = 10.0        # s live per wake
    # --- tier three: woken by tier two ------------------------------------
    P3_pwr: float = 10.0        # W when live (LWIR core + edge inference)
    t3:     float = 30.0        # s live per escalation (capture + inference + decide)
    t_boot: float = 10.0        # s at full power for imager settle + module resume
    P3_standby: float = 0.0     # W held continuously between escalations (design: 0)
    # --- fixed loads ------------------------------------------------------
    HK_pwr: float = 2e-3        # W housekeeping (conditioning, monitoring, losses)
    # --- recall receiver ---------------------------------------------------
    # A.9 shows the always-on wake-up stage cannot reach the design standoff, so
    # recall runs on the sensitive receiver opened on a schedule. Two lines, like
    # every other tier: a standing listening cost and an event-driven message cost.
    RX_pwr:   float = 30e-3     # W while live (-120 dBm scheduled receiver)
    rx_win:   float = 1.0       # s detection window
    rx_period:float = 60.0      # s between windows
    L_bits:   float = 200.0     # bits in an authenticated command (32+8+32+128)
    R_bps:    float = 1.0       # bit/s, chosen for 60 dB of processing gain
    n_cmd:    float = 3.0       # messages actually received per day
    # --- effect -----------------------------------------------------------
    eff_pwr:  float = 20.0      # W servo during an engagement
    eff_t:    float = 5.0       # s per engagement
    eff_n:    float = 5.0       # engagements across the emplacement
    horizon:  float = 30.0      # days

def budget(p: Params) -> dict:
    """All energies in Wh per emplaced-day unless named otherwise."""
    N2 = p.T * p.p1 + p.F1                      # tier-two wakes/day
    N3 = p.T * p.p1 * p.p2 + p.F1 * p.q2        # tier-three escalations/day
    E1 = p.P1_pwr * 24
    E2 = p.P2_pwr * p.t2 * N2 / 3600
    e3_per = p.P3_pwr * (p.t3 + p.t_boot) / 3600          # Wh per escalation
    E3 = e3_per * N3 + p.P3_standby * 24
    EHK = p.HK_pwr * 24
    ERX_listen = p.RX_pwr * (86400 / p.rx_period) * p.rx_win / 3600
    ERX_msg = p.RX_pwr * (p.L_bits / p.R_bps) * p.n_cmd / 3600
    ERX = ERX_listen + ERX_msg
    EEF = p.eff_pwr * p.eff_t * p.eff_n / 3600 / p.horizon
    total = E1 + E2 + E3 + EHK + ERX + EEF
    undisc = total - E3                          # the same object without tier three
    return dict(N2=N2, N3=N3, E1=E1, E2=E2, E3=E3, EHK=EHK, ERX=ERX, EEF=EEF,
                ERX_listen=ERX_listen, ERX_msg=ERX_msg,
                t_msg=p.L_bits / p.R_bps,
                gp_db=10 * math.log10(1e6 / p.R_bps),
                recall_worst_s=p.rx_period + p.L_bits / p.R_bps,
                e3_per=e3_per, total=total, undisc=undisc,
                multiple=total / undisc, share3=E3 / total,
                over_horizon=total * p.horizon)

def show(p: Params, label: str):
    b = budget(p)
    mWh = lambda x: x * 1000
    print(f"\n=== {label} ===")
    print(f"  tier-two wakes/day  N2 = T*p1 + F1                = {b['N2']:.2f}")
    print(f"  escalations/day     N3 = T*p1*p2 + F1*q2          = {b['N3']:.3f}")
    print(f"  energy per escalation                             = {mWh(b['e3_per']):.1f} mWh")
    print(f"  ---------------------------------------------------------------")
    for k, name in [("E1","tier one, continuous"), ("E2","tier two, woken"),
                    ("E3","tier three, woken"), ("ERX","receiver"),
                    ("EHK","housekeeping"), ("EEF","effect")]:
        print(f"  {name:<26} {mWh(b[k]):>9.2f} mWh/day   {b[k]/b['total']*100:>5.1f}%")
    print(f"  ---------------------------------------------------------------")
    print(f"  TOTAL                      {mWh(b['total']):>9.2f} mWh/day = {b['total']:.3f} Wh/day")
    print(f"  over {p.horizon:.0f} days               {b['over_horizon']:>9.2f} Wh")
    print(f"  undiscriminating variant   {mWh(b['undisc']):>9.2f} mWh/day")
    print(f"  discrimination multiple    {b['multiple']:>9.2f}x")
    return b

if __name__ == "__main__":
    print("PARAMETER VECTOR")
    for k, v in asdict(Params()).items(): print(f"  {k:<12} = {v}")
    base = show(Params(), "DESIGN POINT (flat receiver)")
    hb = show(Params(rx_period=6*3600.0, rx_win=200.0, n_cmd=0.0),
              "HEARTBEAT VARIANT (one authenticated 'continue' every 6 h)")
    print("\n=== v2.3.0 published figures, for comparison ===")
    old = show(Params(F1=30.0 - 2*0.95, t_boot=0.0), "as published (F1 implied by 30 tier-two wakes, no boot term)")

# ---------------------------------------------------------------- analysis
import random, statistics as st
from dataclasses import replace

def elasticities(p: Params):
    """d(ln total)/d(ln x): per cent change in total per per cent change in x."""
    base = budget(p)["total"]; out = {}
    for f in ("P1_pwr","T","F1","p1","p2","q2","P2_pwr","t2",
              "P3_pwr","t3","t_boot","HK_pwr","RX_pwr"):
        v = getattr(p, f)
        if v == 0: continue
        hi = budget(replace(p, **{f: v * 1.01}))["total"]
        out[f] = (hi - base) / base * 100
    return dict(sorted(out.items(), key=lambda kv: -abs(kv[1])))

def standby_penalty(p: Params):
    rows = []
    for mw in (0, 1, 10, 100, 300):
        b = budget(replace(p, P3_standby=mw/1000))
        rows.append((mw, b["total"], b["total"] / budget(p)["total"]))
    return rows

RANGES = _R
_UNUSED = {   # superseded by parameters.RANGES; retained for diff clarity
 "P3_pwr": (3.0, 20.0),    "t3": (20.0, 45.0),   "t_boot": (5.0, 20.0),
 "F1": (100.0, 400.0),     "q2": (0.020, 0.082), "T": (1.0, 5.0),
 "P1_pwr": (300e-6, 800e-6), "P2_pwr": (30e-3, 80e-3), "t2": (5.0, 15.0),
 "HK_pwr": (1e-3, 4e-3),
}

def monte_carlo(n=N_DRAWS, seed=SEED):
    rng = random.Random(seed); tot, disc, mult = [], [], []
    for _ in range(n):
        kw = {k: rng.triangular(lo, hi, getattr(Params(), k)) for k,(lo,hi) in RANGES.items()}
        b = budget(Params(**kw))
        tot.append(b["total"]); disc.append(b["E3"]); mult.append(b["multiple"])
    q = lambda v,p_: st.quantiles(v, n=100)[p_-1]
    return {"total": (q(tot,5), st.median(tot), q(tot,95)),
            "disc":  (q(disc,5), st.median(disc), q(disc,95)),
            "mult":  (q(mult,5), st.median(mult), q(mult,95)), "n": n,
            "samples_total": tot}

if __name__ == "__main__":
    p = Params()
    print("\n=== ELASTICITY: %% change in total per 1%% change in parameter ===")
    for k, v in elasticities(p).items(): print(f"  {k:<10} {v:+.4f}")
    print("\n=== TIER-THREE STANDBY (retention state) PENALTY ===")
    for mw, t, r in standby_penalty(p):
        print(f"  standby {mw:>4} mW -> total {t:7.3f} Wh/day  ({r:5.2f}x the zero-standby design)")
    print("\n=== MONTE CARLO over stated component ranges ===")
    mc = monte_carlo()
    f = lambda t, u, s=1: f"{t[0]*s:.3g} / {t[1]*s:.3g} / {t[2]*s:.3g} {u}"
    print(f"  n = {mc['n']:,}  (triangular over each range, mode at the design point)")
    print(f"  total  (5th/50th/95th): {f(mc['total'],'Wh/emplaced-day')}")
    print(f"  tier three             : {f(mc['disc'],'mWh/day',1000)}")
    print(f"  discrimination multiple: {f(mc['mult'],'x')}")
