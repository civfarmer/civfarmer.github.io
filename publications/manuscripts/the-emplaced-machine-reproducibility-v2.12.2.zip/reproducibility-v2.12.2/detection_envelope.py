#!/usr/bin/env python3
"""The energy-constrained detection range, and the usable field envelope.

Formalises the coupling §17.4 states qualitatively: raising tier-one sensitivity
extends nominal detection range and raises the false-trip rate in the same motion,
and the false trips are what the budget spends on. There is therefore a range
beyond which the system cannot be *afforded*, distinct from the range at which the
sensor stops working.

Every relation here is stated; the two that are not derived from the paper's own
cited physics are labelled ILLUSTRATIVE and are what the experiment at A.2 measures.
"""
import math
from dataclasses import dataclass, replace
from budget_and_cascade import Params, budget

# --- the sensing model -------------------------------------------------------
# Transmission loss for a Rayleigh surface wave, in the form the cited study gives:
# a geometric term (amplitude ~ r^-1/2, i.e. 10 log10 r in amplitude dB) plus an
# excess term proportional to range x frequency, 30 dB per 100 m at 100 Hz.
R0, ALPHA = 1.0, 0.30           # m, dB/m at 100 Hz
S0    = 73.65                   # dB re threshold unit, footfall source level  [ILLUSTRATIVE]
                                # calibrated so that at the design threshold the P_D = 0.9
                                # range is the 30 m the cited field trials report
SIGMA = 6.0                     # dB, gait/site/coupling spread               [ILLUSTRATIVE]
F_REF, TH_REF = 200.0, 40.0     # false trips/day at the reference threshold   [ILLUSTRATIVE]
DECADE = 10.0                   # dB of threshold that divides false trips by ten

def signal_db(r):
    """Received footfall level at range r."""
    return S0 - 10 * math.log10(max(r, R0) / R0) - ALPHA * r

def _phi(z):
    return 0.5 * (1 + math.erf(z / math.sqrt(2)))

def p_detect(r, th):
    """P(tier one registers a genuine event at range r, at threshold th)."""
    return _phi((signal_db(r) - th) / SIGMA)

def false_trips(th):
    """Tier-one false trips per day at threshold th."""
    return F_REF * 10 ** (-(th - TH_REF) / DECADE)

def range_at(pd_target, th, hi=400.0):
    """Range at which P_D falls to the target, at this threshold."""
    lo = 0.5
    if p_detect(lo, th) < pd_target:
        return 0.0
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        if p_detect(mid, th) >= pd_target: lo = mid
        else: hi = mid
    return lo

def day_energy(th, pd=0.95, base=None):
    """Daily budget at this threshold: the cascade of 17.3 with F1 set by th and
    tier-one detection probability set to the value the threshold delivers."""
    p = base or Params()
    return budget(replace(p, F1=false_trips(th), p1=pd))

def envelope(pd_target=0.95, e_cap=None, f_cap=None, base=None):
    """R_E: the greatest P_D-satisfying range whose false-trip rate and daily
    energy both stay inside their caps. Returns (R_E, threshold, budget)."""
    best = (0.0, None, None)
    th = 10.0
    while th <= 90.0:
        r = range_at(pd_target, th)
        b = day_energy(th, pd_target, base)
        ok = (e_cap is None or b["total"] <= e_cap) and (f_cap is None or false_trips(th) <= f_cap)
        if ok and r > best[0]:
            best = (r, th, b)
        th += 0.25
    return best

if __name__ == "__main__":
    print("=" * 78)
    print("ENERGY-CONSTRAINED DETECTION RANGE")
    print("=" * 78)
    print(f"  {'threshold':>10s} {'R at P_D=.95':>13s} {'F1/day':>10s} {'N3/day':>8s} "
          f"{'Wh/day':>9s} {'30 d, Wh':>10s}")
    for th in (60, 50, 45, 40, 35, 30, 25, 20):
        b = day_energy(float(th))
        print(f"  {th:>8.0f} dB {range_at(0.95, float(th)):>11.1f} m {false_trips(float(th)):>10.1f} "
              f"{b['N3']:>8.1f} {b['total']:>9.3f} {b['over_horizon']:>10.1f}")
    print()
    for cap in (0.5, 1.0, 1.221, 2.0, 4.0):
        r, th, b = envelope(e_cap=cap)
        print(f"  energy cap {cap:>5.3f} Wh/day  ->  R_E = {r:5.1f} m at threshold {th:.1f} dB "
              f"(F1 = {false_trips(th):.0f}/day, {b['over_horizon']:.0f} Wh over 30 days)")
    print()
    r_unc, th_unc = range_at(0.95, 10.0), 10.0
    print(f"  unconstrained by energy, the front end reaches {r_unc:.0f} m at a {th_unc:.0f} dB threshold,")
    print(f"  which costs {day_energy(th_unc)['total']:.1f} Wh/day and {day_energy(th_unc)['over_horizon']:.0f} Wh over thirty days.")
