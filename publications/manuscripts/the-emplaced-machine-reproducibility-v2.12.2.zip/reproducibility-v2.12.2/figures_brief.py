#!/usr/bin/env python3
"""Two figures sized natively for the six-page CCW brief, so type prints at full size."""
import math, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from propagation_and_jamming import plane_earth_db, w_to_dbm
from budget_and_cascade import Params, budget
from dataclasses import replace

S1, S2 = "#2a78d6", "#eb6834"
INK, MUTE, GRID = "#0b0b0b", "#52514e", "#d8d7d2"
HT, EX, MG, GT, GR = 10.0, 12.0, 10.0, 6.0, 0.0

plt.rcParams.update({
    "font.family": "serif", "font.size": 8, "axes.labelsize": 8,
    "legend.fontsize": 7.5, "figure.dpi": 200,
    "axes.edgecolor": MUTE, "axes.linewidth": 0.7, "text.color": INK,
    "axes.labelcolor": INK, "xtick.color": MUTE, "ytick.color": MUTE,
    "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "savefig.bbox": "tight",
})
def frame(ax):
    for s in ("top","right"): ax.spines[s].set_visible(False)
    ax.grid(True, color=GRID, lw=0.5, alpha=0.9); ax.set_axisbelow(True)

# --- brief figure 1: readiness-energy trade (native 3.5 in) --------------
p = Params()
pts = [(5,3,12),(5,5,20),(10,10,30),(10,15,45),(15,20,60)]
xs = [a+b+c for a,b,c in pts]
ys = [budget(replace(p,t2=a,t_boot=b,t3=c))["total"] for a,b,c in pts]
fig, ax = plt.subplots(figsize=(3.1, 1.85))
ax.plot(xs, ys, color=S1, lw=1.8, marker="o", ms=4, mec="white", mew=1.0)
i = xs.index(50)
ax.plot([50],[ys[i]], "o", ms=7, color=S1, mec="white", mew=1.4, zorder=5)
ax.annotate(f"design point\n{ys[i]:.2f} Wh/day at 50 s", (50, ys[i]), xytext=(9,-6),
            textcoords="offset points", fontsize=7.5, color=INK, ha="left", va="top")
ax.set_xlim(12, 105); ax.set_ylim(0, max(ys)*1.15)
ax.set_xlabel("Readiness interval (s)")
ax.set_ylabel("Wh per emplaced-day")
frame(ax); fig.savefig("figb1-readiness.png"); plt.close(fig)

# --- brief figure 2: recall link budget (native 4.6 in) ------------------
def rng_km(tx_w, sens, hr=0.5):
    b = w_to_dbm(tx_w) + GT + GR - sens - EX - MG
    return 10**((b + 20*math.log10(HT) + 20*math.log10(hr))/40)/1000
fig, ax = plt.subplots(figsize=(4.6, 2.6))
P = [1*1.06**i for i in range(120)]
ax.axhspan(5, 15, color=MUTE, alpha=0.10, lw=0)
ax.text(440, 12.6, "design case: control station\n5–15 km to the rear",
        fontsize=7, color=MUTE, va="center", ha="right")
ax.plot(P, [rng_km(x, -120.0) for x in P], color=S1, lw=1.8,
        label="Receiver gated to a scheduled window  (−120 dBm)")
ax.plot(P, [rng_km(x, -90.0) for x in P], color=S2, lw=1.8, ls="--",
        label="Always-on wake-up stage  (−90 dBm)")
for w in (20,):
    ax.plot([w],[rng_km(w,-120.0)], "o", ms=4.5, color=S1, mec="white", mew=1.1, zorder=5)
    ax.annotate(f"{rng_km(w,-120.0):.1f} km at {w} W", (w, rng_km(w,-120.0)),
                xytext=(10,-13), textcoords="offset points", fontsize=7.5, color=S1)
    ax.plot([w],[rng_km(w,-90.0)], "o", ms=4.5, color=S2, mec="white", mew=1.1, zorder=5)
    ax.annotate(f"{rng_km(w,-90.0):.1f} km at {w} W", (w, rng_km(w,-90.0)),
                xytext=(-9,11), textcoords="offset points", fontsize=7.5, color=S2, ha="right")
ax.set_xscale("log"); ax.set_xlim(1, 500); ax.set_ylim(0, 26)
ax.set_xlabel("Transmit power at the control station (W)")
ax.set_ylabel("Range achieved (km)")
ax.xaxis.set_major_formatter(FuncFormatter(lambda v,_: f"{v:g}"))
ax.legend(frameon=False, loc="upper left", bbox_to_anchor=(0.0,1.04)); frame(ax)
fig.savefig("figb2-linkbudget.png"); plt.close(fig)
print("brief figures written: figb1-readiness figb2-linkbudget")

# --- brief figure 2b: the recall coupling (native 4.6 in) ----------------
Bw, Lb = 1e6, 200.0
def gp2(t): return 10*math.log10(Bw/(Lb/t))
def standoff2(jam_w, gp, d_link=5000, tx_w=20, hr=0.5, margin=10.0):
    s = w_to_dbm(tx_w) + GT + GR - plane_earth_db(d_link, HT, hr) - EX
    return 10**((w_to_dbm(jam_w) - (s + gp - margin) + 20*math.log10(HT) + 20*math.log10(hr))/40)/1000
fig, ax = plt.subplots(figsize=(4.1, 2.25))
T = [1*1.06**i for i in range(120)]
lat = [60 + t for t in T]
ax.plot(lat, [standoff2(1000, gp2(t)) for t in T], color=S2, lw=1.8, ls="--", label="1 kW jammer")
ax.plot(lat, [standoff2(100,  gp2(t)) for t in T], color=S1, lw=1.8, label="100 W jammer")
x, y = 260.0, standoff2(100, gp2(200.0))
ax.plot([x],[y], "o", ms=4.5, color=S1, mec="white", mew=1.1, zorder=5)
ax.annotate("design point\n260 s", (x, y), xytext=(-8,-7), textcoords="offset points",
            fontsize=7.5, color=INK, ha="right", va="top")
ax.set_xscale("log"); ax.set_xlim(60, 1100); ax.set_ylim(0, 3.2)
ax.set_xlabel("Worst-case recall latency (s)")
ax.set_ylabel("Jammer standoff (km)")
ax.xaxis.set_major_formatter(FuncFormatter(lambda v,_: f"{v:g}"))
ax.legend(frameon=False, loc="upper right"); frame(ax)
fig.savefig("figb3-recall.png"); plt.close(fig)
print("written figb3-recall.png")
