#!/usr/bin/env python3
"""Figures for Part VI and Appendix A.9. Every curve is computed, not drawn."""
import math, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from propagation_and_jamming import plane_earth_db, fspl_db, breakpoint_m, w_to_dbm, processing_gain_db, dbm_to_w
from budget_and_cascade import Params, budget, monte_carlo
from dataclasses import replace

S1, S2 = "#2a78d6", "#eb6834"          # validated categorical slots 1 and 2
INK, MUTE, GRID = "#0b0b0b", "#52514e", "#d8d7d2"
F, HT, EX, MG, GT, GR = 150e6, 10.0, 12.0, 10.0, 6.0, 0.0

plt.rcParams.update({
    "font.family": "serif", "font.size": 9, "axes.labelsize": 9,
    "axes.titlesize": 9.5, "legend.fontsize": 8.5, "figure.dpi": 200,
    "axes.edgecolor": MUTE, "axes.linewidth": 0.7, "text.color": INK,
    "axes.labelcolor": INK, "xtick.color": MUTE, "ytick.color": MUTE,
    "xtick.labelsize": 8, "ytick.labelsize": 8, "savefig.bbox": "tight",
})
def frame(ax):
    for s in ("top","right"): ax.spines[s].set_visible(False)
    ax.grid(True, color=GRID, lw=0.5, alpha=0.9); ax.set_axisbelow(True)

# ---------------------------------------------------------------- Fig 1
fig, ax = plt.subplots(figsize=(5.4, 2.9))
d = [10*1.05**i for i in range(220)]
ax.plot(d, [fspl_db(x, F) for x in d], color=S2, lw=2, ls="--", label="Free space  (20 dB/decade)")
ax.plot(d, [plane_earth_db(x, HT, 0.5) for x in d], color=S1, lw=2, label="Two-ray plane earth  (40 dB/decade)")
bp = breakpoint_m(HT, 0.5, F)
ax.axvline(bp, color=MUTE, lw=0.8, ls=":")
ax.text(bp*1.12, 62, f"breakpoint {bp:.0f} m", rotation=90,
        fontsize=7.5, color=MUTE, va="bottom", ha="center")
ax.annotate("50 dB at 10 km", xy=(10000, (fspl_db(10000,F)+plane_earth_db(10000,HT,0.5))/2),
            xytext=(2200, 72), fontsize=8, color=INK,
            arrowprops=dict(arrowstyle="-", color=MUTE, lw=0.7))
ax.plot([10000,10000],[fspl_db(10000,F), plane_earth_db(10000,HT,0.5)], color=MUTE, lw=1.2)
ax.set_xscale("log"); ax.set_xlim(10, 30000); ax.set_ylim(40, 175)
ax.set_xlabel("Range (m)"); ax.set_ylabel("Path loss (dB)")
ax.xaxis.set_major_formatter(FuncFormatter(lambda v,_: f"{v/1000:g} km" if v>=1000 else f"{v:g}"))
ax.legend(frameon=False, loc="upper left"); frame(ax)
fig.savefig("fig1-pathloss.png"); plt.close(fig)

# ---------------------------------------------------------------- Fig 2
def rng_km(tx_w, sens, hr):
    b = w_to_dbm(tx_w) + GT + GR - sens - EX - MG
    return 10**((b + 20*math.log10(HT) + 20*math.log10(hr))/40)/1000
fig, ax = plt.subplots(figsize=(5.4, 3.2))
P = [1*1.06**i for i in range(120)]
ax.axhspan(5, 15, color=MUTE, alpha=0.10, lw=0)
ax.text(430, 6.6, "design case at §15:\ncontrol station\n5–15 km to the rear",
        fontsize=7.5, color=MUTE, va="center", ha="right")
ax.plot(P, [rng_km(p, -120.0, 0.5) for p in P], color=S1, lw=2,
        label="Gated receiver in a scheduled window  (−120 dBm)")
ax.plot(P, [rng_km(p, -90.0, 0.5) for p in P], color=S2, lw=2, ls="--",
        label="Always-on wake-up stage  (−90 dBm)")
for w,lab in ((20,"20 W"),):
    ax.plot([w],[rng_km(w,-120.0,0.5)], "o", ms=5, color=S1, mec="white", mew=1.2, zorder=5)
    ax.annotate(f"{rng_km(w,-120.0,0.5):.1f} km at {lab}", (w, rng_km(w,-120.0,0.5)),
                xytext=(11,-14), textcoords="offset points", fontsize=8, color=S1)
    ax.plot([w],[rng_km(w,-90.0,0.5)], "o", ms=5, color=S2, mec="white", mew=1.2, zorder=5)
    ax.annotate(f"{rng_km(w,-90.0,0.5):.1f} km at {lab}", (w, rng_km(w,-90.0,0.5)),
                xytext=(10,7), textcoords="offset points", fontsize=8, color=S2)
ax.set_xscale("log"); ax.set_xlim(1, 500); ax.set_ylim(0, 26)
ax.set_xlabel("Transmit power at the control station (W)"); ax.set_ylabel("Range achieved (km)")
ax.xaxis.set_major_formatter(FuncFormatter(lambda v,_: f"{v:g}"))
ax.legend(frameon=False, loc="upper left", bbox_to_anchor=(0.02,1.02)); frame(ax)
fig.savefig("fig2-linkbudget.png"); plt.close(fig)

# ---------------------------------------------------------------- Fig 3
def standoff_km(jam_w, gp, d_link=5000, tx_w=20, hr=0.5, margin=10.0):
    s = w_to_dbm(tx_w)+GT+GR-plane_earth_db(d_link,HT,hr)-EX
    loss = w_to_dbm(jam_w) - (s + gp - margin)
    return 10**((loss + 20*math.log10(HT) + 20*math.log10(hr))/40)/1000
fig, ax = plt.subplots(figsize=(5.4, 2.9))
J = [1*1.07**i for i in range(110)]
ax.plot(J, [standoff_km(j, processing_gain_db(1e6,100)) for j in J], color=S2, lw=2, ls="--",
        label="100 bit/s   (processing gain 40 dB)")
ax.plot(J, [standoff_km(j, processing_gain_db(1e6,1)) for j in J], color=S1, lw=2,
        label="1 bit/s   (processing gain 60 dB)")
ax.set_xscale("log"); ax.set_xlim(1, 1000); ax.set_ylim(0, 4)
ax.set_xlabel("Jammer power (W)"); ax.set_ylabel("Denial standoff (km)")
ax.xaxis.set_major_formatter(FuncFormatter(lambda v,_: f"{v:g}"))
ax.legend(frameon=False, loc="upper left"); frame(ax)
fig.savefig("fig3-jamming.png"); plt.close(fig)

# ---------------------------------------------------------------- Fig 4
p = Params()
fig, ax = plt.subplots(figsize=(5.4, 2.8))
pts = [(5,3,12),(5,5,20),(10,10,30),(10,15,45),(15,20,60)]   # exactly the five rows of the table at 17.3
xs = [a+b+c for a,b,c in pts]
ys = [budget(replace(p,t2=a,t_boot=b,t3=c))["total"] for a,b,c in pts]
ax.plot(xs, ys, color=S1, lw=2, marker="o", ms=4.5, mec="white", mew=1.1)
i = xs.index(50)
ax.plot([50],[ys[i]], "o", ms=8, color=S1, mec="white", mew=1.5, zorder=5)
ax.annotate(f"design point\n{ys[i]:.2f} Wh/day at 50 s", (50, ys[i]), xytext=(-11,9),
            textcoords="offset points", fontsize=8, color=INK, ha="right")
ax.set_xlim(12, 105); ax.set_ylim(0, max(ys)*1.15)
ax.set_xlabel("Readiness interval, tier-one trip to release decision available (s)")
ax.set_ylabel("Total (Wh per emplaced-day)")
frame(ax); fig.savefig("fig4-readiness.png"); plt.close(fig)

# ---------------------------------------------------------------- Fig 5
mc  = monte_carlo()                      # 200,000 draws, the paper's own figures
tot = mc["samples_total"]
q5, med, q95 = mc["total"]
dp  = budget(Params())["total"]
fig, ax = plt.subplots(figsize=(5.4, 2.9))
counts, _, _ = ax.hist(tot, bins=100, range=(0, 6), color=S1, alpha=0.85,
                       edgecolor="white", linewidth=0.25)
top = counts.max()*1.02            # reference lines stop at the data, leaving the legend clear
ax.plot([dp, dp],   [0, top], color=S2,  lw=2.0, label=f"design point   {dp:.2f}", zorder=5)
ax.plot([med, med], [0, top], color=INK, lw=1.2, label=f"median   {med:.2f}", zorder=5)
ax.plot([q5, q5],   [0, top], color=INK, lw=1.1, ls="--", zorder=5,
        label=f"5th / 95th percentile   {q5:.2f}, {q95:.2f}")
ax.plot([q95, q95], [0, top], color=INK, lw=1.1, ls="--", zorder=5)
ax.set_xlim(0, 6); ax.set_ylim(0, counts.max()*1.58)
ax.set_xlabel("Total (Wh per emplaced-day)")
ax.set_ylabel(f"Draws (of {mc['n']:,})")
ax.legend(frameon=False, loc="upper right", handlelength=1.8)
frame(ax); fig.savefig("fig5-montecarlo.png"); plt.close(fig)

print("figures written: fig1-pathloss fig2-linkbudget fig3-jamming fig4-readiness fig5-montecarlo")
