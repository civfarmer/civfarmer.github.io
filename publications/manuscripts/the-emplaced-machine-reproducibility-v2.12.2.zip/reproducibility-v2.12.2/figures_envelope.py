#!/usr/bin/env python3
"""Figure: the energy-constrained detection range."""
import math, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from detection_envelope import range_at, day_energy, false_trips
from budget_and_cascade import Params, budget

S1, S2 = "#2a78d6", "#eb6834"
INK, MUTE, GRID = "#0b0b0b", "#52514e", "#d8d7d2"
plt.rcParams.update({"font.family":"serif","font.size":9,"axes.labelsize":9,
    "legend.fontsize":8.5,"figure.dpi":200,"axes.edgecolor":MUTE,"axes.linewidth":0.7,
    "text.color":INK,"axes.labelcolor":INK,"xtick.color":MUTE,"ytick.color":MUTE,
    "xtick.labelsize":8,"ytick.labelsize":8,"savefig.bbox":"tight"})

TH = [60 - 0.25*i for i in range(201)]           # 60 dB down to 10 dB
R  = [range_at(0.95, t) for t in TH]
E  = [day_energy(t)["total"] for t in TH]
design = budget(Params())["total"]

fig, ax = plt.subplots(figsize=(5.4, 3.0))
ax.plot(R, E, color=S1, lw=2)
ax.axhline(design, color=S2, lw=1.6, ls="--")
ax.annotate(f"budget at §17.3, {design:.2f} Wh/day", (2, design*3.4), fontsize=8, color=S2)
r_d = range_at(0.95, 40.0)
ax.plot([r_d], [design], "o", ms=6, color=S1, mec="white", mew=1.3, zorder=5)
ax.annotate(f"affordable range\n{r_d:.0f} m", (r_d, design), xytext=(9, -8),
            textcoords="offset points", fontsize=8, color=INK, ha="left", va="top")
r_hw = range_at(0.95, 10.0)
ax.axvline(r_hw, color=MUTE, lw=0.9, ls=":")
ax.text(r_hw - 2, 300, "front end's own limit, %.0f m" % r_hw, rotation=90,
        fontsize=7.5, color=MUTE, va="top", ha="right")
ax.set_yscale("log"); ax.set_xlim(0, 118); ax.set_ylim(0.15, 2000)
ax.set_xlabel("Detection range at $P_D$ = 0.95 (m)")
ax.set_ylabel("Total (Wh per emplaced-day)")
for s in ("top","right"): ax.spines[s].set_visible(False)
ax.grid(True, color=GRID, lw=0.5, alpha=0.9); ax.set_axisbelow(True)
fig.savefig("fig-envelope.png"); plt.close(fig)
print("written fig-envelope.png")
for cap, lab in ((design/2, "half"), (design, "design"), (design*2, "double"), (design*4, "quadruple")):
    from detection_envelope import envelope
    r, th, b = envelope(e_cap=cap)
    print(f"  {lab:>10s} budget {cap:6.3f} Wh -> R_E {r:5.1f} m")

# brief-sized variant
plt.rcParams.update({"font.size":8,"axes.labelsize":8,"xtick.labelsize":7.5,"ytick.labelsize":7.5})
fig, ax = plt.subplots(figsize=(4.1, 2.25))
ax.plot(R, E, color=S1, lw=1.8)
ax.axhline(design, color=S2, lw=1.4, ls="--")
ax.annotate("budget, 1.22 Wh/day", (2, design*3.4), fontsize=7.5, color=S2)
ax.plot([r_d],[design], "o", ms=5, color=S1, mec="white", mew=1.1, zorder=5)
ax.annotate("30 m", (r_d, design), xytext=(8,-7), textcoords="offset points",
            fontsize=7.5, color=INK, ha="left", va="top")
ax.axvline(r_hw, color=MUTE, lw=0.9, ls=":")
ax.text(r_hw-2, 250, "sensor limit, %.0f m" % r_hw, rotation=90, fontsize=7, color=MUTE,
        va="top", ha="right")
ax.set_yscale("log"); ax.set_xlim(0,118); ax.set_ylim(0.15,2000)
ax.set_xlabel("Detection range at $P_D$ = 0.95 (m)"); ax.set_ylabel("Wh per emplaced-day")
for s in ("top","right"): ax.spines[s].set_visible(False)
ax.grid(True, color=GRID, lw=0.5, alpha=0.9); ax.set_axisbelow(True)
fig.savefig("figb4-envelope.png"); plt.close(fig)
print("written figb4-envelope.png")
