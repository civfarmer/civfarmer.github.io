#!/usr/bin/env python3
"""Figure 3: what recall timeliness costs in jam resistance, in the units a commander uses."""
import math, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
from propagation_and_jamming import plane_earth_db, w_to_dbm

S1, S2 = "#2a78d6", "#eb6834"
INK, MUTE, GRID = "#0b0b0b", "#52514e", "#d8d7d2"
HT, EX, GT, GR = 10.0, 12.0, 6.0, 0.0
B, L = 1e6, 200.0                       # spread bandwidth, authenticated message length
plt.rcParams.update({"font.family":"serif","font.size":9,"axes.labelsize":9,
    "legend.fontsize":8.5,"figure.dpi":200,"axes.edgecolor":MUTE,"axes.linewidth":0.7,
    "text.color":INK,"axes.labelcolor":INK,"xtick.color":MUTE,"ytick.color":MUTE,
    "xtick.labelsize":8,"ytick.labelsize":8,"savefig.bbox":"tight"})

def gp_db(t_msg): return 10*math.log10(B / (L / t_msg))
def standoff_km(jam_w, gp, d_link=5000, tx_w=20, hr=0.5, margin=10.0):
    s = w_to_dbm(tx_w) + GT + GR - plane_earth_db(d_link, HT, hr) - EX
    loss = w_to_dbm(jam_w) - (s + gp - margin)
    return 10**((loss + 20*math.log10(HT) + 20*math.log10(hr))/40)/1000

fig, ax = plt.subplots(figsize=(5.4, 3.0))
T = [1*1.06**i for i in range(120)]                       # message time, s
lat = [60 + t for t in T]                                 # worst case: window + message
ax.plot(lat, [standoff_km(100, gp_db(t)) for t in T], color=S1, lw=2,
        label="100 W jammer")
ax.plot(lat, [standoff_km(1000, gp_db(t)) for t in T], color=S2, lw=2, ls="--",
        label="1 kW jammer")
for t, lab in ((200.0, "design point\n260 s, 60 dB"),):
    x, y = 60+t, standoff_km(100, gp_db(t))
    ax.plot([x],[y], "o", ms=6, color=S1, mec="white", mew=1.3, zorder=5)
    ax.annotate(lab, (x, y), xytext=(13, -11), textcoords="offset points",
                fontsize=8, color=INK, ha="left", va="top")
ax.set_xscale("log"); ax.set_xlim(60, 1100); ax.set_ylim(0, 3.2)
ax.set_xlabel("Worst-case recall latency: listening interval plus message (s)")
ax.set_ylabel("Jammer denial standoff (km)")
ax.xaxis.set_major_formatter(FuncFormatter(lambda v,_: f"{v:g}"))
ax.legend(frameon=False, loc="upper right")
for s in ("top","right"): ax.spines[s].set_visible(False)
ax.grid(True, color=GRID, lw=0.5, alpha=0.9); ax.set_axisbelow(True)
fig.savefig("fig-recall.png"); plt.close(fig)
print("written fig-recall.png")
for t in (1, 10, 40, 200, 1000):
    print(f"  t_msg {t:>5} s  latency {60+t:>5} s  Gp {gp_db(t):5.1f} dB  "
          f"standoff@100W {standoff_km(100, gp_db(t)):.2f} km  @1kW {standoff_km(1000, gp_db(t)):.2f} km")
