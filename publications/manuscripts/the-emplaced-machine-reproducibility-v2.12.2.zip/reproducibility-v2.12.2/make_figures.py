#!/usr/bin/env python3
"""Regenerate every figure in the manuscript from the declared inputs.
    python3 make_figures.py
Requires matplotlib; everything else is the CPython standard library."""
import pathlib, runpy, sys
HERE = pathlib.Path(__file__).parent
sys.path.insert(0, str(HERE))
for m in ("figures_budget", "figures_recall", "figures_envelope", "figures_brief"):
    if (HERE / f"{m}.py").exists():
        print(f"--- {m} ---")
        runpy.run_module(m, run_name="__main__")
    else:
        print(f"--- {m}: absent from this archive ---")

# The scripts emit working names; the manuscript numbers figures in document order.
CANONICAL = {
    "fig4-readiness.png":  "fig1-readiness.png",     # 17.3
    "fig5-montecarlo.png": "fig2-montecarlo.png",    # 17.4
    "fig-envelope.png":    "fig3-envelope.png",      # 17.5  ILLUSTRATIVE
    "fig-recall.png":      "fig4-recall.png",        # 25.2
    "fig1-pathloss.png":   "fig5-pathloss.png",      # A.9.1
    "fig2-linkbudget.png": "fig6-linkbudget.png",    # A.9.2
    "fig3-jamming.png":    "fig7-jamming.png",       # A.9.3
}
tmp = {}
for src in CANONICAL:
    f = HERE / src
    if f.exists():
        tmp[src] = f.read_bytes()
for src, dst in CANONICAL.items():
    if src in tmp:
        (HERE / dst).write_bytes(tmp[src])
for src in CANONICAL:
    if src not in CANONICAL.values() and (HERE / src).exists():
        (HERE / src).unlink()
print("\nmanuscript figures:", sorted(
    p.name for p in HERE.glob("fig[0-9]-*.png")))
print("brief figures:", sorted(p.name for p in HERE.glob("figb*.png")))
