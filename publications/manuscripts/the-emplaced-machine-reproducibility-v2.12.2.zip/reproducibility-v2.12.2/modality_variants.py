#!/usr/bin/env python3
"""Modality terms E_m, the constrained range R_E(m,z), the envelope fractions eta,
the coverage measures Phi, the authority gate, and the weather transfer chain.
Sections 15.5, 17.3, 17.5, 17.6.

EVERY input is a named argument. Nothing is defaulted to a value the manuscript
has not declared, and no military design point is asserted anywhere in this file.
The public commercial proxy powers below are MANUFACTURER-REPORTED electrical
power for commercial sensors; they are not measurements, not peer-reviewed, and
not claims about any fielded military system. A.11 measures the rest.
"""
import math
from parameters import PARAMS
from budget_and_cascade import Params, budget
from dataclasses import replace as _dc_replace

def replace_p1(p1_W):
    """Params with the tier-one continuous power set to p1_W, all else at the design point."""
    return _dc_replace(Params(), P1_pwr=p1_W)

# --------------------------------------------------------------------------
# Public commercial proxy envelope.  MANUFACTURER-REPORTED, no DOI.
# Used only to expose the SCALE of the omitted term. See the source audit.
# --------------------------------------------------------------------------
PROXY_W = {
    "Livox Mid-360":      (6.5,  "average; manufacturer notes peak may reach 14 W in "
                                 "self-heating mode between -20 and 0 C"),
    "Ouster OS2 (Rev7)":  (20.0, "manual specifies a supply of at least 20 W; cold-condition "
                                 "peak 22-28 W, 28 W at -40 C; >=30 W recommended outdoors"),
    "Hesai OT128":        (29.0, "manufacturer-reported power consumption"),
}
PROXY_ENVELOPE_W = (6.5, 29.0)

# A published figure for a MILITARY-ADJACENT SUB-COMPONENT, kept separate from the
# commercial proxy envelope because it is a CAMERA specification and not a system one.
# BAE Systems Geiger-mode lidar camera product page, accessed 27 August 2026.
GMAPD_CAMERA_W = {
    "BAE GmAPD camera, synchronous":  (18.0, "power at saturation; 128x32 format, 1.3 kg, 900 cm^3"),
    "BAE GmAPD camera, asynchronous": (50.0, "power at saturation, stated as '<50 W'; 32x32, 1.5 kg"),
}
# Aull et al. 2018, IEEE JSTQE 24(2) 3800510, full text examined:
READOUT_CHIP_W = 0.5      # R7 framed readout chip ALONE, 20 kframes/s, 1000 events/frame
# Marino et al. 2003, Proc SPIE 5086, full text examined (numbers read from the page image):
TX_PULSE_J     = 33e-6    # up to about 33 uJ per pulse at 532 nm
TX_PRF_HZ      = 10_000.0 # up to about 10 kHz
IFOV_MRAD      = (10.3, 10.3)   # total instantaneous field of view of the 32x32 array
PIX_IFOV_URAD  = 333.0    # projected 100 um pixel pitch
IMAGING_RATE_HZ = (5_000.0, 10_000.0)

def tx_average_optical_W(E_pulse_J=TX_PULSE_J, prf_Hz=TX_PRF_HZ):
    """Average OPTICAL output of the transmitter.  NOT an electrical input.
    Marino's own figures give about 0.33 W, against 0.5 W for the readout chip alone
    and 18 W for an integrated camera: the energy is in the receiver.  15.5.1.2."""
    return E_pulse_J * prf_Hz

# --------------------------------------------------------------------------
# E_m by architecture.  The four are NOT interchangeable.
# --------------------------------------------------------------------------
def E_event_driven(N3, alpha_m, E_start_J, P_m_W, t_obs_s, E_proc_J):
    """Invocation energy, Wh/day.  15.5.2, 17.3.

        E_m = (N3 * alpha_m / 3600) * (E_start + P_m * t_obs + E_proc)

    E_start and E_proc are per-invocation joules; P_m watts; t_obs seconds.
    Startup, observation and processing are separate terms ON PURPOSE: folding
    them into P_m*t_obs hides two of the three, and A.11 measures all three.
    """
    return (N3 * alpha_m / 3600.0) * (E_start_J + P_m_W * t_obs_s + E_proc_J)

def E_event_driven_simplified(alpha_m, P_m_W, t_obs_s, N3=10.0):
    """Sensitivity form that TEMPORARILY OMITS startup and processing energy.
    At N3 = 10 events/day this is E_m[mWh/day] = 2.7778 * alpha_m * P_m * t_obs."""
    return (N3 * alpha_m / 3600.0) * (P_m_W * t_obs_s) * 1000.0   # mWh/day

def E_survey(E_survey_J, horizon_days=30.0):
    """One-time survey amortised over the horizon.  Wh/day."""
    return (E_survey_J / 3600.0) / horizon_days

def E_scheduled(n_sweeps_per_day, E_sweep_J):
    """Scheduled search.  Wh/day.  NOT the event-driven expression."""
    return n_sweeps_per_day * E_sweep_J / 3600.0

SR_PER_DEG2 = (180.0 / math.pi) ** 2      # 3282.806... deg^2 per steradian

def omega_rect_sr(theta_az_deg, theta_el_deg):
    """EXACT solid angle of a centred rectangular sector, steradians.  15.5.1.3.

        Omega_rect = 4 arcsin[ sin(theta_az/2) sin(theta_el/2) ]

    The planar product theta_az * theta_el overstates this: at 60 x 10 degrees by
    4.6 per cent.  v2.12.0 used the planar product; v2.12.1 uses this."""
    a = math.radians(theta_az_deg) / 2.0
    b = math.radians(theta_el_deg) / 2.0
    return 4.0 * math.asin(math.sin(a) * math.sin(b))

def omega_fov_sr(mrad_a, mrad_b):
    """Total instantaneous field of view in steradians.  At milliradian scale the
    small-angle product and the exact expression agree to seven figures."""
    return (mrad_a * 1e-3) * (mrad_b * 1e-3)

def sweep(omega_S_sr, omega_FOV_sr, t_point_s, P_m_W, kappa=1.0):
    """Cost of ONE sector sweep.  15.5.1.3.

        N_point = kappa * Omega_S / Omega_FOV
        E_sweep = P_m(N_A) * t_point * N_point

    Returns (pointings, active seconds, mWh).  The dwell and overlap assumptions are
    deliberately favourable to the sensor; the PROXY POWERS ARE NOT LOWER BOUNDS, so
    the result is an illustrative estimate and not a floor.  Excludes scan overlap,
    mechanical step and settle, startup, transmitter, pointing and processing."""
    n = kappa * omega_S_sr / omega_FOV_sr
    t = n * t_point_s
    return n, t, P_m_W * t / 3.6

def ifov_deg2(mrad_a, mrad_b):
    return omega_fov_sr(mrad_a, mrad_b) * SR_PER_DEG2

def E_continuous(P_m_W, duty=1.0):
    """Continuous active sensing.  Wh/day.  Approaches 24*P_m at unity duty.
    A separate architecture, outside the paper's baseline budget."""
    return 24.0 * P_m_W * duty

ARCHITECTURES = ("passive", "one_time_survey", "event_driven", "scheduled", "continuous")

# --------------------------------------------------------------------------
# Weather: raw returns, and their transfer into system-level cues.  2.2
# --------------------------------------------------------------------------
def F_raw_per_day(tau_on_s_per_day, lambda_density, area_m2):
    """Raw unwanted detections per day.

        F_raw(z) = tau_on * integral over A of lambda(x,z) dA

    lambda_density is detections per second per square metre; the integral is
    approximated here by a uniform density over `area_m2`.  This is a RAW-RETURN
    quantity and is NOT a system false-alarm rate."""
    return tau_on_s_per_day * lambda_density * area_m2

def F1_modality(q_survive, F_raw_day):
    """System-level cue rate from raw returns.

        F_1,m(z,theta) = q_survive,m(z,theta) * F_raw(z)

    q_survive is the probability an unwanted raw detection survives sensor
    filtering, clustering, temporal-consistency checks and tracking to become a
    system cue.  UNKNOWN until measured under A.11."""
    if q_survive is None:
        raise ValueError("q_survive is unmeasured; A.11 determines it. "
                         "Refusing to substitute a value.")
    return q_survive * F_raw_day

def N3_with_cueing_modality(T, p1, p2, F1_passive, q2_passive, F1_m, q2_m):
    """Modality-separated cascade, for the case where the active modality is
    PERMITTED TO ORIGINATE A CUE:

        N3 = T p1 p2 + F1_passive q2_passive + F1_m q2_m
    """
    return T * p1 * p2 + F1_passive * q2_passive + F1_m * q2_m

def t_obs_weather(t_m0_s, n_retry, t_retry_s):
    """Weather-dependent observation duration for the CONFIRMATORY case, where the
    active modality never originates a cue:

        t_obs,m(z) = t_m,0 + n_retry(z) * t_retry

    Carried back into E_event_driven."""
    return t_m0_s + n_retry * t_retry_s

# --------------------------------------------------------------------------
# R_E, envelopes, authority.  17.5, 17.6, 15.5.4
# --------------------------------------------------------------------------
def R_E(p_D, p_ID_given_D, F1_of, E_day_of, thetas, ranges,
        pD_star, pID_star, F_star, E_star, sigma_ok=lambda th: True):
    """R_E(m,z; E*, S*) = sup over admissible theta of sup{ r : all constraints hold }."""
    best_r, best_th = 0.0, None
    for th in thetas:
        if not sigma_ok(th):      continue
        if F1_of(th) > F_star:    continue
        if E_day_of(th) > E_star: continue
        ok = [r for r in ranges
              if p_D(r, th) >= pD_star and p_ID_given_D(r, th) >= pID_star]
        if ok and max(ok) > best_r:
            best_r, best_th = max(ok), th
    return best_r, best_th

def P_D_and_ID(pD, pID_given_D):
    return pD * pID_given_D

def eta(mu_U, mu_C_effect):
    if mu_C_effect <= 0: raise ValueError("effect-envelope measure must be positive")
    return mu_U / mu_C_effect

def phi_area(mu_U_m2, E_day_Wh):      return mu_U_m2 / E_day_Wh   # m^2 Wh^-1 day
def phi_frontage(L_U_m, E_day_Wh):    return L_U_m / E_day_Wh     # m   Wh^-1 day

def R_usable(R_cue, R_ID, R_pose, R_authority, R_effect):
    return min(R_cue, R_ID, R_pose, R_authority, R_effect)

def authority_ok(U_m_members, A_H_members):
    return set(U_m_members) <= set(A_H_members)

def gate(x, A_H_members, V, Gamma):
    """The common downstream gate.  Modality-independent by construction: the
    perception output determines WHICH x is proposed, never whether it passes."""
    return bool(V) and bool(Gamma) and (x in set(A_H_members))

def delta_m(before, after, keys=("P_D","P_ID_given_D","F1","q2","E_day","Sigma",
                                 "C_cue","C_ident","C_pose")):
    out = {}
    for k in keys:
        a, b = after.get(k), before.get(k)
        d = (a - b) if isinstance(a, (int, float)) and isinstance(b, (int, float)) else None
        out[k] = (b, a, d)
    return out

def material(delta, validated_bounds):
    for k, bound in validated_bounds.items():
        d = delta.get(k, (None, None, None))[2]
        if d is not None and abs(d) > bound:
            return True, k
    return False, None

# --------------------------------------------------------------------------
if __name__ == "__main__":
    base = budget(Params())["total"]
    N3   = budget(Params())["N3"]
    print("=" * 78)
    print("PUBLIC COMMERCIAL PROXY ENVELOPE  (manufacturer-reported; not measurements)")
    print("=" * 78)
    for k, (w, note) in PROXY_W.items():
        print(f"  {k:<22} {w:>5.1f} W   {note}")
    print(f"\n  envelope used in the manuscript: {PROXY_ENVELOPE_W[0]}-{PROXY_ENVELOPE_W[1]} W")

    print("\n" + "=" * 78)
    print("ILLUSTRATIVE SENSITIVITY  (N3 = 10/day, alpha_m = 1, t_obs = 1 s)")
    print("EXCLUDES startup and incremental processing energy")
    print("=" * 78)
    print(f"  {'proxy power':>12} {'E_m':>14} {'% of the':>12}")
    print(f"  {'':>12} {'mWh/day':>14} {f'{base:.3f} Wh/day':>12}")
    for w in (6.5, 10.0, 20.0, 29.0):
        e = E_event_driven_simplified(1.0, w, 1.0, N3=10.0)
        print(f"  {w:>10.1f} W {e:>13.1f} {100*e/1000/base:>11.2f}%")
    print("\n  A ten-second observation multiplies each by ten:")
    for w in (6.5, 29.0):
        e = E_event_driven_simplified(1.0, w, 10.0, N3=10.0)
        print(f"    {w:>4.1f} W, 10 s -> {e:>6.1f} mWh/day  ({100*e/1000/base:.1f}% of baseline)")

    print("\n" + "=" * 78)
    print("THE FULL INVOCATION EXPRESSION, with startup and processing RESTORED")
    print("=" * 78)
    print("  E_m = (N3 * alpha_m / 3600) * (E_start + P_m * t_obs + E_proc)")
    print("  Startup and processing energy are UNMEASURED. To show only what they do")
    print("  to the arithmetic, here is 20 W for 1 s with a symbolic E_start = E_proc = J:")
    for J in (0.0, 5.0, 20.0, 100.0):
        e = E_event_driven(10.0, 1.0, J, 20.0, 1.0, J) * 1000
        print(f"    E_start = E_proc = {J:>5.1f} J  ->  {e:>7.1f} mWh/day"
              f"  ({100*e/1000/base:>5.2f}% of baseline)")
    print("  Two unmeasured terms of 100 J each would exceed the observation term")
    print("  elevenfold. This is why they may not be folded into P_m * t_obs.")

    print("\n" + "=" * 78)
    print("THE FOUR ARCHITECTURES ARE NOT INTERCHANGEABLE")
    print("=" * 78)
    print(f"  passive baseline                E_m = 0                 {base:.4f} Wh/day")
    print(f"  one-time survey  (S joules)     E_m = S/3600/30")
    print(f"  event-driven                    E_m = (N3 a/3600)(Es + P t + Ep)")
    print(f"  scheduled search (n sweeps)     E_m = n Esweep/3600")
    print(f"  continuous, 20 W                E_m = {E_continuous(20.0):.1f} Wh/day"
          f"   ({E_continuous(20.0)/base:.0f}x the whole passive budget)")

    print("\n" + "=" * 78)
    print("WHERE THE ENERGY ACTUALLY SITS  (15.5.1.2)")
    print("=" * 78)
    print(f"  transmitter, average OPTICAL output   {tx_average_optical_W():.2f} W"
          f"   (33 uJ x 10 kHz, Marino 2003)")
    print(f"  readout chip ALONE                    {READOUT_CHIP_W:.2f} W"
          f"   (R7, 20 kframes/s, 1000 events/frame, Aull 2018)")
    for k, (w, note) in GMAPD_CAMERA_W.items():
        print(f"  {k:<37} {w:.1f} W   {note}")
    print(f"  paper's tier-one continuous floor      {PARAMS['P1_pwr'][0]*1000:.3f} mW")
    print(f"  ratio, readout chip : tier-one floor   {READOUT_CHIP_W/PARAMS['P1_pwr'][0]:.0f}x")

    print("\n" + "=" * 78)
    print("COST OF ONE SECTOR SWEEP  (15.5.1.3) -- illustrative estimate, favourable to the sensor")
    print("=" * 78)
    fov = omega_fov_sr(*IFOV_MRAD)
    OmS = omega_rect_sr(60.0, 10.0)
    planar = math.radians(60.0) * math.radians(10.0)
    print(f"  instantaneous field {IFOV_MRAD[0]} x {IFOV_MRAD[1]} mrad"
          f" = {fov:.6e} sr = {fov*SR_PER_DEG2:.5f} deg^2")
    print(f"  sector 60 x 10 deg, EXACT solid angle = {OmS:.5f} sr = {OmS*SR_PER_DEG2:.1f} deg^2"
          f"   ({100*(1 - OmS/planar):.1f}% smaller than the planar product)")
    print(f"  kappa = 1, t_point = 10 ms")
    for w in (6.5, 18.0, 20.0, 29.0):
        n, ts, mwh = sweep(OmS, fov, 0.010, w)
        print(f"    {w:>5.1f} W -> {n:7.0f} pointings, {ts:5.1f} s, {mwh:6.1f} mWh/sweep"
              f"   ({base*1000/mwh:5.1f} sweeps = the whole passive budget;"
              f" 1/hour = {24*mwh/1000:.2f} Wh/day = {100*24*mwh/1000/base:.0f}%)")
    print("  E_sweep is proportional to P_m(N_A)/N_A: a bigger array pays only to the")
    print("  extent that receiver power grows SUB-linearly with format.")

    print("\n" + "=" * 78)
    print("ONE-TIME SURVEY, AMORTISED  (15.5.2) -- NOT assumed negligible")
    print("=" * 78)
    for mins in (1.0, 5.0):
        wh = 29.0 * mins / 60.0
        print(f"  {mins:>4.0f} min at 29 W = {wh:6.4f} Wh -> /30 d = {wh/30*1000:6.1f} mWh/day"
              f"  ({100*wh/30/base:5.2f}% of baseline)")
    print("  Externally supplied at emplacement -> platform budget unchanged, logistics are not.")
    print("  Battery supplied -> E_survey must be MEASURED and amortised over H.")

    print("\n" + "=" * 78)
    print("TIER-ONE ROBUSTNESS  (17.3) -- P_1 varied alone, all else at the design point")
    print("=" * 78)
    print(f"  P_1 = P_WU,audio + P_WU,seismic + P_gate/leak")
    print(f"  published acoustic anchor: 305.5 uW (300 uW MEMS mic + 5.5 uW classifier),")
    print(f"    a CHIP without back-end modules; the 194.5 uW remainder is an UNMEASURED allowance")
    print(f"  {'P_1':>10} {'tier one':>12} {'total':>12} {'30 days':>10}")
    for p1 in (305.5e-6, 500e-6, 1e-3):
        b2 = budget(replace_p1(p1))
        print(f"  {p1*1e6:>8.1f} uW {p1*24*1000:>10.3f} mWh {b2['total']:>10.4f} Wh"
              f" {b2['total']*30:>9.2f} Wh")
    b1000 = budget(replace_p1(1e-3))["total"]; b500 = budget(replace_p1(500e-6))["total"]
    print(f"  doubling 500 uW -> 1 mW moves the total by {100*(b1000/b500 - 1):.2f}%:"
          f" P_1 is not load-bearing for the endurance conclusion.")

    print("\n" + "=" * 78)
    print("WEATHER TRANSFER  (2.2) -- refuses to invent q_survive")
    print("=" * 78)
    print("  F_raw(z) = tau_on * lambda(z) * A      raw unwanted detections per day")
    print("  F_1,m(z) = q_survive * F_raw(z)        system-level cue rate")
    try:
        F1_modality(None, 1.0)
    except ValueError as e:
        print(f"  F1_modality(q_survive=None, ...) -> ValueError: {e}")
    print("  Raw-return density is NOT a system false-alarm rate. A.11 determines the")
    print("  transfer coefficient for the architecture actually tested.")

    print("\n" + "=" * 78)
    print("AUTHORITY INVARIANT AND COMMON GATE  (15.5.4)")
    print("=" * 78)
    A_H = {"sector_a", "sector_b"}
    print(f"  U_passive = {{sector_a}}          subset of A_H : {authority_ok({'sector_a'}, A_H)}")
    print(f"  U_lidar   = {{a,b,c}} (larger)    subset of A_H : {authority_ok({'sector_a','sector_b','sector_c'}, A_H)}"
          "   -> clip the envelope, do not enlarge A_H")
    print(f"  gate('sector_c', A_H, V=1, G=1) = {gate('sector_c', A_H, 1, 1)}   (outside the ceiling, whatever saw it)")
    print(f"  gate('sector_a', A_H, V=0, G=1) = {gate('sector_a', A_H, 0, 1)}   (survey integrity failed)")
    print(f"  gate('sector_a', A_H, V=1, G=1) = {gate('sector_a', A_H, 1, 1)}")
