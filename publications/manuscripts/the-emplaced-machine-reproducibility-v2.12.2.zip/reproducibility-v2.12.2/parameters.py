#!/usr/bin/env python3
"""The single canonical parameter file. Every script imports from here; no value
is repeated by hand anywhere in the package or in the manuscript.

CLASS column: 'assumption' = stipulated by the author; 'component' = a published
manufacturer or vendor figure for a class of part; 'design' = a design choice;
'stipulation' = adopted from an external instrument. NOTHING here is a measurement
made by this paper.
"""
PARAMS = {
    # symbol            value      unit      class          note
    "P1_pwr":        (500e-6,     "W",     "assumption", "tier-one continuous; largest unsourced line (A.2)"),
    "T":             (2.0,        "1/day", "assumption", "genuine events entering the sector"),
    "F1":            (200.0,      "1/day", "assumption", "tier-one false trips (A.2 measures)"),
    "p1":            (0.95,       "-",     "assumption", "P(tier one registers a genuine event)"),
    "p2":            (0.95,       "-",     "assumption", "P(tier two confirms)"),
    "q2":            (0.041,      "-",     "assumption", "P(tier two passes a false trip)"),
    "P2_pwr":        (50e-3,      "W",     "component",  "tier two live"),
    "t2":            (10.0,       "s",     "assumption", "tier-two live time per wake"),
    "P3_pwr":        (10.0,       "W",     "component",  "LWIR core + edge inference, published figures"),
    "t3":            (30.0,       "s",     "assumption", "tier-three live time per escalation"),
    "t_boot":        (10.0,       "s",     "assumption", "settle and resume at full power"),
    "P3_standby":    (0.0,        "W",     "design",     "gated to zero between escalations"),
    "HK_pwr":        (2e-3,       "W",     "assumption", "housekeeping"),
    "RX_pwr":        (30e-3,      "W",     "component",  "scheduled receiver while live, -120 dBm class"),
    "rx_win":        (1.0,        "s",     "design",     "detection window"),
    "rx_period":     (60.0,       "s",     "design",     "interval between windows"),
    "L_bits":        (200.0,      "bit",   "design",     "authenticated command PAYLOAD (25.2)"),
    "R_bps":         (1.0,        "bit/s", "design",     "information rate, chosen for 60 dB Gp"),
    "n_cmd":         (3.0,        "1/day", "assumption", "messages received per day"),
    "eff_pwr":       (20.0,       "W",     "assumption", "servo during an engagement"),
    "eff_t":         (5.0,        "s",     "assumption", "per engagement"),
    "eff_n":         (5.0,        "-",     "assumption", "engagements across the emplacement"),
    "horizon":       (30.0,       "day",   "stipulation","AP II Technical Annex, remotely delivered AP mines"),
}
# Monte Carlo: triangular, mode at the design point. JUDGEMENT bounds, not hard bounds.
RANGES = {
    "P3_pwr": (3.0, 20.0), "t3": (20.0, 45.0), "t_boot": (5.0, 20.0),
    "F1": (100.0, 400.0),  "q2": (0.020, 0.082), "T": (1.0, 5.0),
    "P1_pwr": (300e-6, 800e-6), "P2_pwr": (30e-3, 80e-3), "t2": (5.0, 15.0),
    "HK_pwr": (1e-3, 4e-3),
}
SEED, N_DRAWS = 20260826, 200000
GENERATOR = "python random.Random(seed).triangular (CPython stdlib)"
QUANTILE_DEFINITION = ("statistics.quantiles(data, n=100, method='exclusive'); "
                       "the 5th and 95th percentiles are elements [4] and [94]")
INDEPENDENT = True   # sampled independently; see README on why this is questionable

# Link, propagation and recall constants
LINK = {"f_hz": 150e6, "h_t": 10.0, "h_r": 0.5, "G_t": 6.0, "G_r": 0.0,
        "L_ex": 12.0, "M_fade": 10.0, "B_spread": 1e6}

def values():
    return {k: v[0] for k, v in PARAMS.items()}

if __name__ == "__main__":
    w = max(len(k) for k in PARAMS)
    print(f"{'symbol'.ljust(w)}  {'value':>12}  {'unit':<6} {'class':<12} note")
    for k, (v, u, c, n) in PARAMS.items():
        print(f"{k.ljust(w)}  {v:>12g}  {u:<6} {c:<12} {n}")
    print(f"\nseed {SEED}, draws {N_DRAWS}, {GENERATOR}")
    print(f"quantiles: {QUANTILE_DEFINITION}")
    print(f"independent sampling: {INDEPENDENT}  (judgement bounds, not hard bounds)")
