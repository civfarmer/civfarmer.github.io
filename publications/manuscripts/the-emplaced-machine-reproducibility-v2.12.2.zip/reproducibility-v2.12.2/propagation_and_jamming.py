#!/usr/bin/env python3
"""Link and jam budget for the receive-only recall channel (§25, §26).

Everything below is arithmetic over standard published propagation and
spread-spectrum relations. No measurement, no proprietary figure.

The governing choice is the propagation model. For a concealed receiving
antenna at or near ground level, free-space (d^-2) is the wrong law: beyond the
first Fresnel breakpoint the two-ray plane-earth model applies and loss goes as
d^-4. Using free-space here would flatter the design by tens of decibels, so the
plane-earth model is used throughout and free space is shown only for contrast.
"""
import math

C = 299_792_458.0

def fspl_db(d_m, f_hz):
    return 20*math.log10(d_m) + 20*math.log10(f_hz) - 147.55

def breakpoint_m(ht, hr, f_hz):
    return 4*math.pi*ht*hr*f_hz/C

def plane_earth_db(d_m, ht, hr):
    """Two-ray flat-earth loss, valid beyond the breakpoint. 40 dB/decade."""
    return 40*math.log10(d_m) - 20*math.log10(ht) - 20*math.log10(hr)

def path_loss_db(d_m, ht, hr, f_hz):
    db = breakpoint_m(ht, hr, f_hz)
    return fspl_db(d_m, f_hz) if d_m < db else max(fspl_db(d_m, f_hz), plane_earth_db(d_m, ht, hr))

def dbm_to_w(x):  return 10**((x-30)/10)
def w_to_dbm(x):  return 10*math.log10(x)+30

def required_tx_dbm(d_m, f_hz, ht, hr, sens_dbm, gt=6.0, gr=0.0, excess=0.0, margin=0.0):
    """EIRP-ish: transmit power needed at the station, given antenna gains."""
    return sens_dbm + path_loss_db(d_m, ht, hr, f_hz) + excess + margin - gt - gr

def processing_gain_db(bw_hz, rate_bps):
    return 10*math.log10(bw_hz/rate_bps)

# ------------------------------------------------------------------ scenario
F      = 150e6      # VHF; low band chosen for terrain diffraction and foliage
HT     = 10.0       # control-station antenna height, m (mast or vehicle)
HR     = 0.5        # emplaced receiver antenna height, m (concealed, near ground)
SENS   = -90.0      # dBm, tuned-RF wake-up receiver (the paper's cited figure)
GT, GR = 6.0, 0.0   # dBi: modest directional at the station, isotropic at the platform
EXCESS = 12.0       # dB, vegetation + terrain clutter allowance
MARGIN = 10.0       # dB, fade margin

print("="*74)
print("RECALL LINK BUDGET  (control station -> emplaced receive-only platform)")
print("="*74)
print(f"  frequency {F/1e6:.0f} MHz   station antenna {HT:.0f} m   platform antenna {HR:.1f} m")
print(f"  receiver sensitivity {SENS:.0f} dBm   gains {GT:.0f}/{GR:.0f} dBi")
print(f"  excess (foliage/clutter) {EXCESS:.0f} dB   fade margin {MARGIN:.0f} dB")
print(f"  two-ray breakpoint at {breakpoint_m(HT,HR,F):.0f} m -- beyond it, 40 dB/decade\n")
print(f"  {'range':>7} {'plane-earth':>12} {'free-space':>11} {'req. TX':>10} {'':>4}")
for d in (1000, 2000, 5000, 10000, 15000):
    pe = plane_earth_db(d, HT, HR); fs = fspl_db(d, F)
    tx = required_tx_dbm(d, F, HT, HR, SENS, GT, GR, EXCESS, MARGIN)
    print(f"  {d/1000:>5.0f} km {pe:>10.1f} dB {fs:>9.1f} dB {tx:>7.1f} dBm  ({dbm_to_w(tx):.2f} W)")

print("\n  empirical sanity check")
print("  A fielded seismic UGS node transmits at 15 mW (11.8 dBm) and is stated to")
print("  reach a gateway at 1-5 km, with options to 10 km. Required TX at 5 km on the")
print(f"  model above is {required_tx_dbm(5000,F,HT,HR,SENS,GT,GR,EXCESS,MARGIN):.1f} dBm; that node's link runs the other way (node")
print("  transmits, gateway listens on a raised antenna), which is the favourable")
print("  geometry, and its receiver is far more sensitive than a wake-up stage.")

# ------------------------------------------------------------------ jamming
print("\n" + "="*74)
print("JAM MARGIN")
print("="*74)
BW = 1e6
print(f"  spread bandwidth {BW/1e6:.0f} MHz. The recall message is a few bytes and may be")
print("  repeated for hours, so the information rate is a free variable:\n")
print(f"  {'rate':>10} {'proc. gain':>12} {'time for 64 bits':>18}")
for r in (100, 10, 1, 0.1):
    print(f"  {r:>8g} b/s {processing_gain_db(BW,r):>9.1f} dB {64/r/60:>15.1f} min")

def jam_denial_w(dj_m, gp_db, d_link_m, tx_dbm, req_ebno_db=10.0):
    """Jammer power needed at standoff dj to push J/S past the processing gain."""
    s = tx_dbm + GT + GR - path_loss_db(d_link_m, HT, HR, F) - EXCESS
    allowed_j = s + gp_db - req_ebno_db          # dBm of jammer power at the receiver
    return dbm_to_w(allowed_j + path_loss_db(dj_m, HT, HR, F))

print(f"\n  Jammer power required to deny the link, by jammer standoff from the platform")
print("  (link range 10 km, station at 20 W, jammer antenna at the same 10 m height)\n")
TX = w_to_dbm(20.0)
print(f"  {'standoff':>10} " + " ".join(f"{('Gp %.0f dB' % processing_gain_db(BW,r)):>13}" for r in (100,1)))
for dj in (500, 1000, 5000, 10000):
    row = " ".join(f"{jam_denial_w(dj, processing_gain_db(BW,r), 10000, TX):>10.1f} kW"
                   .replace("kW","kW") if jam_denial_w(dj,processing_gain_db(BW,r),10000,TX)>=1000
                   else f"{jam_denial_w(dj,processing_gain_db(BW,r),10000,TX):>13.1f} W" for r in (100,1))
    print(f"  {dj/1000:>8.1f} km {row}")
