#!/usr/bin/env python3
"""The recall channel: message length, processing gain, delivery time, safing latency.

Everything here follows from two identities and the link budget already in link.py:
    G_p  = 10 log10(B / R)          processing gain of a direct-sequence link
    t_msg = L / R                   time to deliver an L-bit message at R bit/s
so that
    G_p  = 10 log10(B / L) + 10 log10(t_msg)
which is the result this module exists to state: for a fixed bandwidth and a fixed
message length, every doubling of delivery time buys 3 dB of jam resistance.
"""
import math

B      = 1e6      # spread bandwidth, Hz
RX_PWR = 30e-3    # scheduled receiver power while live, W  (as stated at 25.1)

# A minimally defensible authenticated recall command.
FIELDS = [("platform address", 32), ("command word", 8),
          ("monotonic counter (anti-replay)", 32), ("authentication tag", 128)]
L = sum(n for _, n in FIELDS)

def gp_db(t_msg, bits=L, bw=B):
    """Processing gain available when an L-bit message is spread over t_msg seconds."""
    return 10*math.log10(bw / (bits / t_msg))

def t_for_gp(gp, bits=L, bw=B):
    """Delivery time needed to reach a stated processing gain."""
    return bits / (bw / 10**(gp/10))

def listen_energy_mWh(period_s, t_msg, rx=RX_PWR):
    """Daily energy of a receiver that opens one t_msg window every period_s."""
    return (86400/period_s) * t_msg * rx / 3.6

if __name__ == "__main__":
    print("="*74)
    print("AUTHENTICATED RECALL COMMAND")
    print("="*74)
    for f, n in FIELDS: print(f"  {f:<34s} {n:>4d} bits")
    print(f"  {'total':<34s} {L:>4d} bits")
    print(f"\n  10 log10(B/L) = {10*math.log10(B/L):.1f} dB at B = {B/1e6:.0f} MHz")
    print("  every doubling of delivery time therefore buys 3 dB\n")

    print("="*74)
    print("DELIVERY TIME AGAINST JAM RESISTANCE")
    print("="*74)
    print(f"  {'rate':>10s} {'delivery time':>16s} {'proc. gain':>12s}")
    for R in (200, 50, 20, 5, 2, 1, 0.5, 0.2):
        t = L / R
        print(f"  {R:>8g} b/s {t:>13.0f} s {gp_db(t):>10.1f} dB")

    print("\n" + "="*74)
    print("THE THREE-WAY TRADE: safing latency, jam resistance, platform energy")
    print("="*74)
    print("  A heartbeat architecture: the platform arms only while an authenticated")
    print("  'continue' message keeps arriving, and safes itself when one is missed.")
    print(f"  {'heartbeat period':>18s} {'worst-case safing':>19s} {'proc. gain':>12s} {'listening':>12s}")
    for period, t_msg in ((3600, 200), (3600, 40), (6*3600, 200), (12*3600, 200),
                          (24*3600, 200), (24*3600, 1000)):
        e = listen_energy_mWh(period, t_msg)
        h = period/3600
        print(f"  {h:>15.0f} h {h + t_msg/3600:>16.1f} h {gp_db(t_msg):>10.1f} dB {e:>9.1f} mWh/d")

    print("\n" + "="*74)
    print("RECALL-ON-COMMAND, for comparison (listen 1 s in 60, 30 mW)")
    print("="*74)
    base = listen_energy_mWh(60, 1)
    print(f"  scheduled listening                       {base:>8.1f} mWh/day")
    print(f"  detection gain in a 1 s window            {10*math.log10(B*1.0):>8.1f} dB")
    for R, lab in ((1, "1 b/s"), (5, "5 b/s")):
        t = L/R
        print(f"  message at {lab:<6s} adds {3*t*RX_PWR/3.6:>6.2f} mWh/day"
              f"   ({t:>4.0f} s, {gp_db(t):.1f} dB)  worst-case recall {60+t:>4.0f} s")
